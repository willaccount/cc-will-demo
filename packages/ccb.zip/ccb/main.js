/**
 * https://docs.cocos2d-x.org/creator/manual/en/publish/custom-project-build-template.html
 * 
 */

'use strict';

var path = require('path');
var fs = require('fs');

// ============================ LOG ============================

function logg(str, enter = false) { 
  if(enter == undefined || enter == 'undefined' || enter  == false) {
    Editor.log('[ccb]: ' + str);
  }
  else {
    Editor.log(str);
  }
}

// ============== EVENT  BUILD  LISTENER  WITH COCOS PROCESS  ==============

function onBeforeBuildFinish (options, callback) {
  logg('onBeforeBuildFinish ' + options.platform + ' to ' + options.dest); // you can display a log in the Console panel

    // ---------- Example test! ----------
    // var mainJsPath = path.join(options.dest, 'main.js');  // get path of main.js in build folder
    // var script = fs.readFileSync(mainJsPath, 'utf8');     // read main.js
    // script += '\n' + 'window.myID = "01234567";';         // append any scripts as you need
    // fs.writeFileSync(mainJsPath, script);                 // save main.js

    // required to run the next process
    callback();
}

function onBuildFinish(options, callback) {
  logg('onBuildFinish: ' + options.platform + ' to ' + options.dest); // you can display a log in the Console panel

    // ---------- Example test! ----------
    // var mainJsPath = path.join(options.dest, 'main.js');  // get path of main.js in build folder
    // var script = fs.readFileSync(mainJsPath, 'utf8');     // read main.js
    // script += '\n' + 'window.myID = "01234567";';         // append any scripts as you need
    // fs.writeFileSync(mainJsPath, script);                 // save main.js

    /**
     * PWA 
     * Copy file service_worker can't use build process Cocos because hash md5 code will create multi worker 
     * 
     */
    logg(options, true);

    if(options.actualPlatform == 'web-mobile' || options.actualPlatform == 'web-desktop') {
      fs.readFile(options.project+ "/packages/ccb/build-ccb/service_worker.js", function(err, data)
      {
          if(err)
            logg(err);
          else {
            var mainJsPath = path.join(options.dest, 'service_worker.js');
            logg('pwa: apply to ' + mainJsPath);
            fs.writeFileSync(mainJsPath, data.toString());   
          }
      });
    }
    else {
      logg('pwa: NOT apply');
    }
    // ---------- Required to run the next process ----------
    callback();
}


module.exports = {
  load () {
    // When the package loaded
    // Editor.Builder.on('before-change-files', onBeforeBuildFinish);
    Editor.Builder.on('build-finished', onBuildFinish);

  },

  unload () {
    // When the package unloaded
    // Editor.Builder.removeListener('before-change-files', onBeforeBuildFinish);
    Editor.Builder.removeListener('build-finished', onBuildFinish);

  },

  messages: {
    'say-hello' () {
      Editor.log('Hello World!');
    }
  },
};