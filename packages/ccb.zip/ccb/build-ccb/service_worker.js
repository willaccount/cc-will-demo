'use strict';

const CACHENAME = 'ccc-v5';
const DYNAMICCACHE = 'ccc-v5-DynamicCache';

const FILELIST = [
    './'
    // './index.html',
    // './404.html'
];

const FOLDERSCACHE = [
    'res/raw-assets',
    'res/import'
]

self.addEventListener('install', function(e) {
    console.log('install');
    e.waitUntil(
        caches.open(CACHENAME).then(function(cache) {
            console.log('service workder is open cache');
            return cache.addAll(FILELIST);
        })
    )
});

var doesRequestAcceptHtml = function(request) {
    return request.headers.get('Accept')
    .split(',')
    .some(function(type) {
        return type == 'text/html';
    });
;}

self.addEventListener('activate', function(e) {
    console.log('activate');
    e.waitUntil(
        caches.keys().then(function(keyList) {
            return Promise.all(keyList.map(function(key) {
                if(key !== CACHENAME) {
                    console.log('Service worker removing old cache');
                    return caches.delete(key);
                }
            }));
        })
    );

    return self.clients.claim();
});

 var checkCacheFolder = function (url) {
    var isCache = false;
    FOLDERSCACHE.forEach(function(entry) {
        if(url.includes(entry)) {
            isCache = true;
        }
    });
    return isCache;
 }
self.addEventListener('fetch', function(e) {

    var request = e.request;
    var isNeedCache = checkCacheFolder(e.request.url);
    if(isNeedCache == true) {
        e.respondWith(
            fetch(e.request)
            .then(function(res) {
                return caches.open(DYNAMICCACHE)
                            .then(function(cache) {
                                cache.put(e.request.url, res.clone());
                                return res;
                            })
            })
            .catch(function (err) {
                return caches.match(e.request);
            })
        )
    }
    else {
        console.log('----- Request NO cache: ', e.request.url);
    }
});